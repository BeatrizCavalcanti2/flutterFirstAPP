package com.example.appprimeiro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
